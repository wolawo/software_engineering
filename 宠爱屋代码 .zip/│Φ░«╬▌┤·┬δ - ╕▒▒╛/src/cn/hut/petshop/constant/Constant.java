package cn.hut.petshop.constant;

public interface Constant {

	/**
	 * 记住用户名
	 */
	String SAVE_NAME = "ok";

	/**
	 * 热门商品
	 */
	int PRODUCT_IS_HOT = 1;

	/**
	 * 商品未下架
	 */
	int PRODUCT_IS_UP = 0;

	/**
	 * 商品已下架
	 */
	int PRODUCT_IS_DOWN = 1;

	/**
	 * 订单状态 未付款
	 */
	int ORDER_WEIFUKUAN = 0;

	/**
	 * 订单状态 已付款
	 */
	int ORDER_YIFUKUAN = 1;

	/**
	 * 订单状态 已发货
	 */
	int ORDER_YIFAHUO = 2;

	/**
	 * 订单状态 已完成
	 */
	int ORDER_YIWANCHENG = 3;
	
	/**
	 * 管理员权限
	 */
	int IS_ROLE = 1;
	
	/**
	 * 非管理员权限
	 */
	int IS_NOT_ROLE = 0;

}

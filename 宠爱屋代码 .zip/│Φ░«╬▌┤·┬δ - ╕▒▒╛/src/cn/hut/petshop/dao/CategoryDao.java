package cn.hut.petshop.dao;

import java.util.List;

import cn.hut.petshop.domain.Category;

public interface CategoryDao {

	List<Category> findAll() throws Exception;

	void save(Category c) throws Exception;

	Category findByCname(String cname) throws Exception;

	void deleteByCategoryId(String cname) throws Exception;

	void update(String categoryName, String categoryId) throws Exception;

	Category getById(String categoryId) throws Exception;

	List<Category> findDog()throws Exception;

	List<Category> findCat()throws Exception;

	List<Category> findOther() throws Exception;

}

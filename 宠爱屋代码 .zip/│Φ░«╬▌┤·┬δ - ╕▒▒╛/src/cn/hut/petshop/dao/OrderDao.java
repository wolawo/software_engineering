package cn.hut.petshop.dao;

import java.util.List;

import cn.hut.petshop.domain.Order;
import cn.hut.petshop.domain.OrderItem;
import cn.hut.petshop.domain.PageBean;

public interface OrderDao {

	void save(Order order) throws Exception;

	void saveItem(OrderItem oi) throws Exception;

	int getTotalRecord(String uid) throws Exception;

	List<Order> findMyOrdersByPage(PageBean<Order> pb, String uid) throws Exception;

	Order getById(String oid) throws Exception;

	void update(Order order) throws Exception;

	List<Order> findALLByState(String state) throws Exception;

	void deleteOrderById(String oid) throws Exception;
	
}

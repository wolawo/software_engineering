package cn.hut.petshop.dao;

import org.apache.commons.dbutils.QueryRunner;

import cn.hut.petshop.utils.DataSourceUtils;

public interface OrderItemDao {

	void updateProductId(String productId) throws Exception;

	void delItemByOid(String oid) throws Exception;

	

	
}

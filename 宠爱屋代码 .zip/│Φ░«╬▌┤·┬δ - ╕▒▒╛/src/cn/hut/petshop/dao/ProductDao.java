package cn.hut.petshop.dao;

import java.sql.SQLException;
import java.util.List;

import cn.hut.petshop.domain.PageBean;
import cn.hut.petshop.domain.Product;

public interface ProductDao {

	List<Product> findHot() throws Exception;

	List<Product> findNew() throws Exception;

	Product getById(String pid) throws Exception;

	List<Product> findByPage(PageBean<Product> pb, String cid) throws Exception;

	int getTotalRecord(String cid) throws Exception;

	List<Product> findAll() throws Exception;

	void save(Product p) throws Exception;

	void deleteProductsByCategoryID(String cid)throws Exception;

	Product findByPname(String pname) throws Exception;

	List<Product> getByCategoryID(String cid) throws Exception;

	void deleteProductByProductId(String productId) throws Exception;

	void updateProduct(Product p) throws Exception;

	List<Product> findProductByWord(String word) throws Exception;

	List<Product> findByPageAndWord(PageBean<Product> pb, String word) throws Exception;

	int getTotalRecordByWord(String word) throws Exception;

}

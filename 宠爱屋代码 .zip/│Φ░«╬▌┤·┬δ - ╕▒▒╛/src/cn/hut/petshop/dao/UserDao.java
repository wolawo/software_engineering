package cn.hut.petshop.dao;

import java.sql.SQLException;

import cn.hut.petshop.domain.User;

public interface UserDao {

	void save(User user) throws Exception;

	User getByUsernameAndPwd(String username, String password) throws Exception;

	User getByUsername(String username) throws Exception;

}

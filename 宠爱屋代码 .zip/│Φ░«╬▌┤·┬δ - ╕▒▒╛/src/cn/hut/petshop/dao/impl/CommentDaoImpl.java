package cn.hut.petshop.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.sun.org.apache.bcel.internal.generic.NEW;

import cn.hut.petshop.dao.CommentDao;
import cn.hut.petshop.domain.Comment;
import cn.hut.petshop.utils.DataSourceUtils;

public class CommentDaoImpl implements CommentDao {

	@Override
	/**
	 * 发表评论
	 */
	public void insert(Comment comment) throws SQLException {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "insert into comment values(?,?,?,?,?,?,?)";
		qr.update(sql, comment.getId(), comment.getUserid(), comment.getUsername(),
				comment.getTime(), comment.getComment(), comment.getStar(), comment.getProductid());
	}

	@Override
	/**
	 * 通过商品id查询评论
	 */
	public List<Comment> selectALLByPid(String pid) throws SQLException {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from comment where productid = ?";
		return qr.query(sql, new BeanListHandler<>(Comment.class),pid);
		
	}

	@Override
	/**
	 * 查看所有评论
	 */
	public List<Comment> findAll() throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from comment";
		return qr.query(sql, new BeanListHandler<>(Comment.class));
	}

	@Override
	/**
	 * 通过id删除评论
	 */
	public void deleteCommentById(String id) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "delete from comment where id=?";
		qr.update(sql, id);
	}

}

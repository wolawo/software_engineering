package cn.hut.petshop.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.sun.org.apache.bcel.internal.generic.NEW;

import cn.hut.petshop.dao.OrderItemDao;
import cn.hut.petshop.domain.OrderItem;
import cn.hut.petshop.utils.DataSourceUtils;

public class OrderItemDaoImpl implements OrderItemDao {

	@Override
	public void updateProductId(String productId) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "update orderitem set pid='moren' where pid=?";
		qr.update(sql,productId);
	
		
	}

	@Override
	public void delItemByOid(String oid) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		List<OrderItem> list = findItemByOid(oid);
		String delitemSql = "delete from orderitem where itemid = ?";
		for (OrderItem orderItem : list) {
			qr.update(delitemSql, orderItem.getItemid());
		}
	}
	
	private List<OrderItem> findItemByOid(String oid) throws SQLException{
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from orderitem where `oid` = ?";
		return qr.query(sql, new BeanListHandler<OrderItem>(OrderItem.class),oid);
	}

}

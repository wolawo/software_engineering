package cn.hut.petshop.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.hut.petshop.constant.Constant;
import cn.hut.petshop.dao.ProductDao;
import cn.hut.petshop.domain.PageBean;
import cn.hut.petshop.domain.Product;
import cn.hut.petshop.utils.DataSourceUtils;

public class ProductDaoImpl implements ProductDao {

	@Override
	/**
	 * 查询热门商品
	 */
	public List<Product> findHot() throws Exception {
		QueryRunner qr= new QueryRunner(DataSourceUtils.getDataSource());
		String sql="select * from product where is_hot =? and pflag =? order by pdate desc limit 12";		
		return qr.query(sql, new BeanListHandler<>(Product.class),Constant.PRODUCT_IS_HOT,Constant.PRODUCT_IS_UP);
	}

	@Override
	/**
	 * 查询最新商品
	 */
	public List<Product> findNew() throws Exception {
		QueryRunner qr= new QueryRunner(DataSourceUtils.getDataSource());
		String sql="select * from product where pflag =? order by pdate desc limit 12";		
		return qr.query(sql, new BeanListHandler<>(Product.class),Constant.PRODUCT_IS_UP);
	}

	@Override
	/**
	 * 查询单个商品
	 */
	public Product getById(String pid) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from product where pid = ? limit 1";
		
		return qr.query(sql, new BeanHandler<>(Product.class),pid);
	}
	
	
	@Override
	/**
	 * 通过分类查询商品
	 */
	public List<Product> getByCategoryID(String cid) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from product where cid = ? ";
		return qr.query(sql, new BeanListHandler<>(Product.class), cid);
	}
	
	
	@Override
	/**
	 * 删除分类之前更新商品所属分类的id
	 */
	public void deleteProductsByCategoryID(String cid) throws SQLException {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "update product set cid = 'moren' where cid = ?";
		qr.update(sql, cid);
	}
	@Override
	/**
	 * 查询当前页数据
	 */
	public List<Product> findByPage(PageBean<Product> pb, String cid) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from product where cid=? and pflag=? order by pdate desc limit ?,? ";
		return qr.query(sql, new BeanListHandler<>(Product.class),cid,Constant.PRODUCT_IS_UP,pb.getStartIndex(),pb.getPageSize());
	}

	@Override
	/**
	 * 获取总记录数
	 */
	public int getTotalRecord(String cid) throws Exception {
		// TODO Auto-generated method stub
		return ((Long)new QueryRunner(DataSourceUtils.getDataSource()).query("select count(*) from product where cid=? and pflag=?", 
				new ScalarHandler(),cid,Constant.PRODUCT_IS_UP)).intValue();
	}

	@Override
	/**
	 * 后台展示已上架商品
	 */
	public List<Product> findAll() throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from product where pflag =? order by pdate desc , pid <> 'moren'";
		return qr.query(sql, new BeanListHandler<>(Product.class),Constant.PRODUCT_IS_UP);
	}

	@Override
	/**
	 * 保存商品
	 */
	public void save(Product p) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		/**
		 * `pid` varchar(32) NOT NULL,
	  	   `pname` varchar(50) DEFAULT NULL,
	       `market_price` double DEFAULT NULL,
	       
	  	   `shop_price` double DEFAULT NULL,
	  	   `pimage` varchar(200) DEFAULT NULL,
	  	   `pdate` date DEFAULT NULL,
	  	   
	  	   `is_hot` int(11) DEFAULT NULL,
	  	   `pdesc` varchar(255) DEFAULT NULL,
	  	   `pflag` int(11) DEFAULT NULL,
	  	   
	  	   `cid` varchar(32) DEFAULT NULL,
		 */
		String sql = "insert into product values(?,?,?,?,?,?,?,?,?,?)";
		qr.update(sql, p.getPid(),p.getPname(),p.getMarket_price(),
				p.getShop_price(),p.getPimage(),p.getPdate(),
				p.getIs_hot(),p.getPdesc(),p.getPflag(),
				p.getCategory().getCid());
		
	}

	@Override
	/**
	 * 按名字查询
	 */
	public Product findByPname(String pname) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from product where pname =?";
		return qr.query(sql, new BeanHandler<>(Product.class),pname);
	}

	@Override
	/**
	 * 按商品id删除商品
	 */
	public void deleteProductByProductId(String productId) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "delete from product where pid=?";
		qr.update(sql, productId);
		
	}

	@Override
	public void updateProduct(Product p) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "update product set pname=?,market_price=?,shop_price=?,pimage=?,pdate=?,is_hot=?,pdesc=?,pflag=?,cid=? where pid=?";
	
		qr.update(sql,p.getPname(),p.getMarket_price(),
				p.getShop_price(),p.getPimage(),p.getPdate(),
				p.getIs_hot(),p.getPdesc(),p.getPflag(),
				p.getCategory().getCid(),p.getPid());
	}

	@Override
	public List<Product> findProductByWord(String word) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql="select * from product p,category c where p.cid=c.cid and cname like ? and pid <> 'moren'";
		return qr.query(sql, new BeanListHandler<>(Product.class),"%"+word+"%" );
	}

	@Override
	public List<Product> findByPageAndWord(PageBean<Product> pb, String word) throws SQLException {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from product p,category c where p.cid=c.cid and cname like ? and pid <> 'moren' and pflag=? order by pdate desc limit ?,?";
		return qr.query(sql, new BeanListHandler<>(Product.class),"%"+word+"%",Constant.PRODUCT_IS_UP,pb.getStartIndex(),pb.getPageSize());
	}

	@Override
	public int getTotalRecordByWord(String word) throws Exception {
		// TODO Auto-generated method stub
				return ((Long)new QueryRunner(DataSourceUtils.getDataSource()).query("select count(*) from product p,category c where p.cid=c.cid and cname like ? and pid <> 'moren' and pflag=?", 
						new ScalarHandler(),"%"+word+"%",Constant.PRODUCT_IS_UP)).intValue();
	}

                          
}

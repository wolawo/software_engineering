package cn.hut.petshop.dao.impl;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.sun.org.apache.bcel.internal.generic.NEW;
import com.sun.org.apache.bcel.internal.generic.Select;

import cn.hut.petshop.constant.Constant;
import cn.hut.petshop.dao.UserDao;
import cn.hut.petshop.domain.User;
import cn.hut.petshop.utils.DataSourceUtils;

public class UserDaoImpl implements UserDao {

	@Override
	/**
	 * 用户注册
	 */
	public void save(User user) throws SQLException {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql="insert into user(uid,username,password,role) values(?,?,?,?)";
		qr.update(sql,user.getUid(),user.getUsername(),user.getPassword(),
				Constant.IS_NOT_ROLE);
	}

	@Override
	/**
	 * 用户登录
	 */
	public User getByUsernameAndPwd(String username, String password) throws Exception {
		QueryRunner qr=new QueryRunner(DataSourceUtils.getDataSource());
		String sql="Select * from user where username=? and password=? limit 1";
		return qr.query(sql, new BeanHandler<>(User.class),username,password);
	}

	@Override
	public User getByUsername(String username) throws Exception {
		QueryRunner qr=new QueryRunner(DataSourceUtils.getDataSource());
		String sql ="Select * from user where username=?";
		return qr.query(sql, new BeanHandler<>(User.class),username);
	}

}

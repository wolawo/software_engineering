package cn.hut.petshop.domain;

import java.util.Date;

public class Comment {

	/*`id` varchar(32) NOT NULL,
	  `userid` varchar(32) DEFAULT NULL,
	  `username` varchar(20) DEFAULT NULL,
	  `time` date DEFAULT NULL,
	  `comment` varchar(255) DEFAULT NULL,
	  `star` int DEFAULT NULL,
	  `productid` varchar(32) DEFAULT NULL,
	*/
	
	private String id;
	private String userid;
	private String username;
	private Date time;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Integer getStar() {
		return star;
	}
	public void setStar(Integer star) {
		this.star = star;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	private String comment;
	private Integer star;
	private String productid;
	@Override
	public String toString() {
		return "Comment [id=" + id + ", userid=" + userid + ", username=" + username + ", time=" + time + ", comment="
				+ comment + ", star=" + star + ", productid=" + productid + "]";
	}
	
	
	
	
}

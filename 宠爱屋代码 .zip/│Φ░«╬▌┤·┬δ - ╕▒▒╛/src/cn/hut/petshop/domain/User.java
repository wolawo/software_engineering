package cn.hut.petshop.domain;

public class User {
	/** 
	 * CREATE TABLE `user` (
  		`uid` varchar(32) NOT NULL,
  		`username` varchar(20) DEFAULT NULL,
  		`password` varchar(20) DEFAULT NULL,
  		`name` varchar(20) DEFAULT NULL,
  		`email` varchar(30) DEFAULT NULL,
  		`telephone` varchar(20) DEFAULT NULL,
  		`sex` varchar(10) DEFAULT NULL,
  		PRIMARY KEY (`uid`)
) 		ENGINE=InnoDB DEFAULT CHARSET=utf8;
	 */
	
	private String uid;
	private String username;
	private String password;
	private Integer role;
		
	public Integer getRole() {
		return role;
	}
	public void setRole(Integer role) {
		this.role = role;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
			
}

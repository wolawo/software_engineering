package cn.hut.petshop.service;

import java.util.List;

import cn.hut.petshop.domain.Category;

public interface CategoryService {

	String findAll() throws Exception;
	String findDog() throws Exception;
	String findCat() throws Exception;

	List<Category> findList() throws Exception;
	List<Category> findDogList() throws Exception;
	List<Category> findCatList() throws Exception;

	void save(Category c) throws Exception;

	Category findByCname(String cname) throws Exception;

	void delete(String cid) throws Exception;

	void update(String categoryName, String categoryId) throws Exception;

	Category getById(String categoryId) throws Exception;
	String findOther() throws Exception;

}

package cn.hut.petshop.service;

import java.sql.SQLException;
import java.util.List;

import cn.hut.petshop.domain.Comment;

public interface CommentService {

	void save(Comment comment) throws SQLException;

	List<Comment> getComments(String pid) throws SQLException;

	List<Comment> findAll() throws Exception;

	void deleteCommentById(String id) throws Exception;

}

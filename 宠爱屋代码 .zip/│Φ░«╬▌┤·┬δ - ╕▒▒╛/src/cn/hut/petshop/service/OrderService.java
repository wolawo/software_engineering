package cn.hut.petshop.service;

import java.util.List;

import cn.hut.petshop.domain.Order;
import cn.hut.petshop.domain.PageBean;

public interface OrderService {

	void save(Order order) throws Exception;

	PageBean<Order> findMyOrdersByPage(int pageNumber, int pageSize, String uid) throws Exception;

	Order getById(String oid) throws Exception;

	void update(Order order) throws Exception;

	List<Order> findAllByState(String state) throws Exception;

	void deleteOrderById(String oid) throws Exception;
	

}

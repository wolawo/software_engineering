package cn.hut.petshop.service;

import java.sql.SQLException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import cn.hut.petshop.domain.User;

public interface UserService {

	void regist(User user) throws Exception;

	User login(String username, String password) throws Exception;

	User getByUserName(String username) throws Exception;
	
}

package cn.hut.petshop.service.impl;

import java.util.List;

import cn.hut.petshop.dao.CategoryDao;
import cn.hut.petshop.dao.ProductDao;
import cn.hut.petshop.domain.Category;
import cn.hut.petshop.service.CategoryService;
import cn.hut.petshop.utils.BeanFactory;
import cn.hut.petshop.utils.JsonUtil;

public class CategoryServiceImpl implements CategoryService {
	
	@Override
	/**
	 * 后台展示所有分类
	 */
	public List<Category> findList() throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		return cd.findAll();
	}
	
	/**
	 * 展示所有狗分类
	 */
	public List<Category> findDogList() throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		return cd.findDog();
	}
	
	/**
	 * 展示所有猫分类
	 */
	public List<Category> findCatList() throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		return cd.findCat();
	}
	
	/**
	 * 展示所有其他分类
	 */
	public List<Category> findOtherList() throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		return cd.findOther();
	}


	@Override
	/**
	 * 查询所有分类
	 */
	public String findAll() throws Exception {
		/*// 1.调用dao，查询所有分类
		//CategoryDao cd = new CategoryDaoImpl();
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		List<Category> list = cd.findAll();*/
		
		List<Category> list = findList();
		
		
		// 2.将list转换成json字符串
		if (list != null && list.size() > 0) {
			return JsonUtil.list2json(list);
		}
		return null;
	}
	/**
	 * 查询所有猫分类
	 * @return
	 * @throws Exception
	 */
	public String findCat() throws Exception {
		/*// 1.调用dao，查询所有分类
		//CategoryDao cd = new CategoryDaoImpl();
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		List<Category> list = cd.findAll();*/
		
		List<Category> list = findCatList();
		
		
		// 2.将list转换成json字符串
		if (list != null && list.size() > 0) {
			return JsonUtil.list2json(list);
		}
		return null;
	}
	
	/**
	 * 查询所有狗分类
	 * @return
	 * @throws Exception
	 */
	public String findDog() throws Exception {
		/*// 1.调用dao，查询所有分类
		//CategoryDao cd = new CategoryDaoImpl();
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		List<Category> list = cd.findAll();*/
		
		List<Category> list = findDogList();
		
		
		// 2.将list转换成json字符串
		if (list != null && list.size() > 0) {
			return JsonUtil.list2json(list);
		}
		return null;
		
	}
	
	/**
	 * 查询所有狗分类
	 * @return
	 * @throws Exception
	 */
	public String findOther() throws Exception {
		/*// 1.调用dao，查询所有分类
		//CategoryDao cd = new CategoryDaoImpl();
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		List<Category> list = cd.findAll();*/
		
		List<Category> list = findOtherList();
		
		
		// 2.将list转换成json字符串
		if (list != null && list.size() > 0) {
			return JsonUtil.list2json(list);
		}
		return null;
		
	}


	@Override
	/**
	 * 添加分类
	 */
	public void save(Category c) throws Exception {
		//1.调用dao 完成添加
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		cd.save(c);
		
	}

	@Override
	/**
	 * 通过分类名字查询
	 */
	public Category findByCname(String cname) throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		return cd.findByCname(cname);
	}

	@Override
	/**
	 * 删除分类
	 */
	public void delete(String cid) throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		ProductDao productDao = (ProductDao) BeanFactory.getBean("ProductDao");
		productDao.deleteProductsByCategoryID(cid);
		cd.deleteByCategoryId(cid);
	}

	@Override
	/**
	 * 修改分类名称
	 */
	public void update(String categoryName,String categoryId) throws Exception {
		CategoryDao categoryDao = (CategoryDao) BeanFactory.getBean("CategoryDao");
		categoryDao.update(categoryName,categoryId);
		
	}

	@Override
	/**
	 * 通过Id获取分类
	 */
	public Category getById(String categoryId) throws Exception {
		CategoryDao categoryDao = (CategoryDao) BeanFactory.getBean("CategoryDao");
		Category category = categoryDao.getById(categoryId);
		return category;
	}

	
}

package cn.hut.petshop.service.impl;

import java.sql.SQLException;
import java.util.List;

import cn.hut.petshop.dao.CommentDao;
import cn.hut.petshop.dao.impl.CommentDaoImpl;
import cn.hut.petshop.domain.Comment;
import cn.hut.petshop.service.CommentService;
import cn.hut.petshop.utils.BeanFactory;

public class CommentServiceImpl implements CommentService {

	@Override
	/**
	 * 发表评论
	 */
	public void save(Comment comment) throws SQLException {
		CommentDao commentDao = (CommentDao) BeanFactory.getBean("CommentDao");
		commentDao.insert(comment);
	}

	@Override
	/**
	 * 通过商品id查询评论
	 */
	public List<Comment> getComments(String pid) throws SQLException {
		CommentDao commentDao = (CommentDao) BeanFactory.getBean("CommentDao");
		return commentDao.selectALLByPid(pid);
	}

	@Override
	/**
	 * 查询所有评论
	 */
	public List<Comment> findAll() throws Exception {
		CommentDao commentDao = (CommentDao) BeanFactory.getBean("CommentDao");
		List<Comment> list = commentDao.findAll();
		return list;
	}

	@Override
	/**
	 * 通过id删除评论
	 */
	public void deleteCommentById(String id) throws Exception {
		CommentDao commentDao = (CommentDao) BeanFactory.getBean("CommentDao");
		commentDao.deleteCommentById(id);
		
	}

}

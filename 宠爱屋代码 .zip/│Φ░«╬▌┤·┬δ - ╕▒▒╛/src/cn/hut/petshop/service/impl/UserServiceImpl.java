package cn.hut.petshop.service.impl;

import cn.hut.petshop.dao.UserDao;
import cn.hut.petshop.domain.User;
import cn.hut.petshop.service.UserService;
import cn.hut.petshop.utils.BeanFactory;

public class UserServiceImpl implements UserService {

	@Override
	/**
	 * 用户注册
	 */
	public void regist(User user) throws Exception {
		// 1.调用dao完成注册
		UserDao ud = (UserDao) BeanFactory.getBean("UserDao");
		ud.save(user);

	}

	@Override
	/**
	 * 用户登录
	 */
	public User login(String username, String password) throws Exception {
		UserDao ud = (UserDao) BeanFactory.getBean("UserDao");
		return ud.getByUsernameAndPwd(username, password);
	}

	@Override
	/**
	 * 按照用户名查询
	 */
	public User getByUserName(String username) throws Exception {
		UserDao ud = (UserDao) BeanFactory.getBean("UserDao");
		return ud.getByUsername(username);
	}

}

package cn.hut.petshop.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hut.petshop.domain.Product;
import cn.hut.petshop.service.CategoryService;
import cn.hut.petshop.service.ProductService;
import cn.hut.petshop.utils.BeanFactory;
import cn.hut.petshop.web.servlet.base.BaseServlet;

/**
 * 后台商品模块
 */
public class AdminProductServlet extends BaseServlet {
	
	
	/**
	 * 编辑商品名称
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String editUI(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String productId = request.getParameter("pid");
			
			CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
			request.setAttribute("list", cs.findList());
			
			ProductService productService = (ProductService) BeanFactory.getBean("ProductService");
			Product product = productService.getById(productId);
			request.setAttribute("product", product);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return "/admin/product/edit.jsp";
	}
	
	/**
	 * 按商品id删除商品
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String deleteProductByProductId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String productId = request.getParameter("pid");
			
			ProductService productService = (ProductService) BeanFactory.getBean("ProductService");
			productService.deleteProductByProductId(productId);
			
			List<Product> list = productService.findAll();
			
			//2.将返回值放入request域中，请求转发
			
			request.setAttribute("list", list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "/admin/product/list.jsp";
	}
	
	/**
	 * 跳转到添加的页面上
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String addUI(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//调用categoryservice 查询所有分类
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		try {
			request.setAttribute("list", cs.findList());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "/admin/product/add.jsp";
	}
	
	/**
	 * 展示已上架商品列表
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//1.调用service查询已上架商品
			ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
			List<Product> list = ps.findAll();
			
			//2.将返回值放入request域中，请求转发
			
			request.setAttribute("list", list);
		} catch (Exception e) {
			e.printStackTrace();			
		}
		return "/admin/product/list.jsp";
	}

}

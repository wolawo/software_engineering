package cn.hut.petshop.web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;

import cn.hut.petshop.domain.Comment;
import cn.hut.petshop.domain.User;
import cn.hut.petshop.service.CommentService;
import cn.hut.petshop.service.impl.CommentServiceImpl;
import cn.hut.petshop.utils.BeanFactory;
import cn.hut.petshop.utils.UUIDUtils;
import cn.hut.petshop.web.servlet.base.BaseServlet;

/**
 * 评论
 */
public class CommentServlet extends BaseServlet {
	
	/**
	 * 添加评论
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public void comment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, IllegalAccessException, InvocationTargetException {
		Integer star = Integer.parseInt(request.getParameter("star"));
		String pid = request.getParameter("pid");
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		Comment comment = new Comment();
		BeanUtils.populate(comment, request.getParameterMap());
		comment.setProductid(pid);
		comment.setUserid(user.getUid());
		comment.setUsername(user.getUsername());
		comment.setId(UUIDUtils.getId());
		comment.setTime(new Date());
		comment.setStar(star);
		CommentService commentService = (CommentService) BeanFactory.getBean("CommentService");
		try {
			commentService.save(comment);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/product?method=getById&pid="+comment.getProductid());
	}
	
	/**
	 * 后台显示评论
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		CommentService commentService = (CommentService) BeanFactory.getBean("CommentService");
		List<Comment> list = null;
		try {
			list = commentService.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("list", list);
		return "/admin/comment/list.jsp";
	}
	
	/**
	 * 通过id删除评论
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String deleteCommentById(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		CommentService commentService = (CommentService) BeanFactory.getBean("CommentService");
		List<Comment> list = null;
		try {
			commentService.deleteCommentById(id);
			list = commentService.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("list", list);
		return "admin/comment/list.jsp";
	}

}

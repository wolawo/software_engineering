package cn.hut.petshop.web.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import cn.hut.petshop.domain.Comment;
import cn.hut.petshop.domain.PageBean;
import cn.hut.petshop.domain.Product;
import cn.hut.petshop.service.CommentService;
import cn.hut.petshop.service.ProductService;
import cn.hut.petshop.service.impl.CommentServiceImpl;
import cn.hut.petshop.service.impl.ProductServiceImpl;
import cn.hut.petshop.utils.BeanFactory;
import cn.hut.petshop.web.servlet.base.BaseServlet;

/**
 * 前台商品模块
 */
public class ProductServlet extends BaseServlet {
	
	/**
	 * 分类商品分页展示
	 */
	public String findByPage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//1.获取pagenumber cid 设置pagesize
			/*String parameter = request.getParameter("pageNumber");*/
			int pageNumber = 1;
			try {
				pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
			} catch (NumberFormatException e) {
			}
			
			int pageSize = 12;
			String cid = request.getParameter("cid");
			
			//2.调用service 分页查询商品 参数：3个，返回值：pagebean
			ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
			PageBean<Product> bean = ps.findByPage(pageNumber,pageSize,cid);
			
			//3.将pagebean放入request域中，请求转发product_list.jsp 
			request.setAttribute("pb", bean);
		} catch (Exception e) {
			request.setAttribute("msg", "分页查询失败！");
			return "/jsp/msg.jsp";
		}
		return "/jsp/product_list.jsp";
	}
	
	/**
	 * 商品详情
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */

	public String getById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String pid = request.getParameter("pid");
			ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
			Product pro = ps.getById(pid);
			CommentService commentService = (CommentService) BeanFactory.getBean("CommentService");
			List<Comment> list =  commentService.getComments(pid);
			request.setAttribute("comments", list);
			request.setAttribute("bean", pro);
		} catch (Exception e) {
			request.setAttribute("msg", "查询单个商品失败！");
			return "/jsp/msg.jsp";
		}
		return "/jsp/product_info.jsp";
	}
}

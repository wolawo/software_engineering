package cn.hut.petshop.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hut.petshop.domain.PageBean;
import cn.hut.petshop.domain.Product;
import cn.hut.petshop.service.ProductService;
import cn.hut.petshop.service.impl.ProductServiceImpl;
import cn.hut.petshop.utils.BeanFactory;
import cn.hut.petshop.utils.JsonUtil;
import cn.hut.petshop.web.servlet.base.BaseServlet;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends BaseServlet {
	
	
	public String search(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
			//1.获取pagenumber cid 设置pagesize
			/*String parameter = request.getParameter("pageNumber");*/
			int pageNumber = 1;
			try {
				pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
			} catch (NumberFormatException e) {
			}
			
			int pageSize = 12;
			String word=request.getParameter("word");
			request.setAttribute("word", word);
			
			//2.调用service 分页查询商品 参数：3个，返回值：pagebean
			ProductService ps = new ProductServiceImpl();
			PageBean<Product> bean = (PageBean<Product>) ps.findProductByWord(pageNumber,pageSize,word);
			
			//3.将pagebean放入request域中，请求转发product_list.jsp 
			request.setAttribute("pb", bean);
		//获得关键字
		 

		 
		//查询该关键字的所有商品


		 
		//查出来的数据转成json格式，使用json工具将对象或者集合转换成json格式的字符串
		 
		/*JsonArray fromObject=JsonArray.fromObject(productList);
		String string=fromObject.toString();
		System.out.println(string);*/            //jsonlib转换插件
		 
		
//		 
//		String json=JsonUtil.list2json(list);
//		
//		if (list != null && list.size() > 0) {
//			return JsonUtil.list2json(list);
//		}
//		 
//		response.setContentType("text/html;charset=UTF-8");
//		 
//		//结果返回给页面
//		 
//		response.getWriter().write(json);
		return "/jsp/product_search.jsp";

	}
}
//	}
	


